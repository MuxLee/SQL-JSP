window.onload = function () {
	var submit = document.getElementById("submit");
	submit.onclick = function () {
		for (var count = 0; count < document.getElementsByClassName("check").length; count++) {
			if (count == 3 && document.getElementsByClassName("check")[count].value == "") {
				alert(document.getElementsByClassName("name")[count].textContent+"를 입력해주세요");
				document.getElementsByClassName("check")[count].focus();
				return false;
			}
			else if (count != 3 && document.getElementsByClassName("check")[count].options[document.getElementsByClassName("check")[count].selectedIndex].text == "선택") {
				alert(document.getElementsByClassName("name")[count].textContent+"를 선택해주세요");
				document.getElementsByClassName("check")[count].focus();
				return false;
			}
		}
	};
};