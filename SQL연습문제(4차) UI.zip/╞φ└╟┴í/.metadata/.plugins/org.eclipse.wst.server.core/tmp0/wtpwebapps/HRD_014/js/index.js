window.onload = function () {
	var submit = document.getElementById("submit");
	submit.onclick = function () {
		for (var count = 0; count < document.getElementsByClassName("name").length; count++) {
			if (count == 3 && document.getElementById("sale_cnt").value == "") {
				alert(document.getElementsByClassName("name")[count].textContent+"를 입력하지 않으셨습니다.");
				document.getElementById("sale_cnt").focus();
				return false;
			}
			else if (document.getElementsByTagName("select")[count].value == "선택") {
				alert(document.getElementsByClassName("name")[count].textContent+"를 선택하지 않으셨습니다");
				document.getElementsByTagName("select")[count].focus();
				return false;
			}
		}
	};
};