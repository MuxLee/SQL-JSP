window.onload = function () {
	var submit = document.getElementById("submit");
	var select = document.getElementById("select");
	submit.onclick = function () {
		for (var count = 0; count < document.getElementsByClassName("null").length; count++) {
			if (count == 3 && select.options[select.selectedIndex].text == "피자선택") {
				alert("피자코드를 선택해주세요");
				select.focus();
				return false;
			}
			else if (count != 3 && document.getElementsByClassName("null")[count].value == "") {
				alert(document.getElementsByClassName("name")[count].textContent+"을(를) 입력하지 않으셨습니다.");
				document.getElementsByClassName("null")[count].focus();
				return false;
			}
		}
	};
};