function pressKey () {
	alert(document.getElementsByTagName("th")[0].textContent+"을(를) 수정할 수 없습니다");
	event.returnValue = false;
};