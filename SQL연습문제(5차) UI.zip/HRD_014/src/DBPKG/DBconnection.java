package DBPKG;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBconnection {
	
	public static Connection getConnection() throws Exception {
		Class.forName("oracle.jdbc.OracleDriver");
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "oracle");
		return conn;
	}
	
	public static PreparedStatement getPstmt(String args) throws Exception {
		PreparedStatement pstmt = getConnection().prepareStatement(args);
		return pstmt;
	}
	
	public static ResultSet getRs(String args) throws Exception {
		ResultSet rs = getPstmt(args).executeQuery();
		return rs;
	}
	
}
